import express from 'express';
import bodyParser from 'body-parser';
import usersRoutes from './routes/users.js'

const app = express(); //whole app in this

const PORT = 5000;
app.use(bodyParser.json()); // we gonna use json data

app.use('/users', usersRoutes);

app.get('/', (req, res) => {
    res.send('hello from home page');
});
//handling users APIS 



app.listen(PORT, () => console.log(` Server listening on port: http://localhost${PORT}`)); // ctrl + c to stop terminal