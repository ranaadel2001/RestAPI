import { v4 as uuidv4 } from 'uuid';
let users = [];

export const getUser = (req, res) => {

    res.send(users);

}


export const createUser = (req, res) => {
    const user = req.body;


    users.push({...user, id: uuidv4() });


    res.send(`user with the name ${user.Firstname} added to db`)
}


export const getUserById = (req, res) => {
    const { id } = req.params;
    const foundUser = users.find((user) => user.id === id);

    if (foundUser) {
        res.send(foundUser);
    } else {
        res.status(404).send('User not found');
    }
}


export const deleteUser = (req, res) => {
    const { id } = req.params;
    users = users.filter((user) => user.id !== id);

    res.send(`User with id ${id} is deleted`);
}


export const updateUser = (req, res) => {
    const { id } = req.params;
    const { Firstname, Lastname, age } = req.body;
    const userToBeUpdated = users.find((user) => user.id === id);

    if (userToBeUpdated) {
        if (Firstname) {
            userToBeUpdated.Firstname = Firstname;
        }
        if (Lastname) {
            userToBeUpdated.Lastname = Lastname;
        }
        if (age) {
            userToBeUpdated.age = age;
        }

        res.send(`User with the id ${id} is updated`);
    } else {
        res.status(404).send('User not found');
    }
}